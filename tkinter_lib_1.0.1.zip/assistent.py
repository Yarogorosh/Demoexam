from langchain_gigachat import GigaChat
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage
API_KEY = "MjkzMzZmOWMtZDE4OC00OGU5LWI5Y2ItY2JjMWFlNGZkYzRlOjJhOGVkNDk1LTdlMWQtNDNlOS04Yzg1LTlkZDZiMGNlMjZhOA=="
llm = GigaChat(credentials=API_KEY, verify_ssl_certs=False)
system_prompt = SystemMessage(content="""Ты специалист в области программирования на Python.
Помоги мне сдать демонстрационный экзамен. Я буду отправлять тебе код и задания к нему, исправляй и подсказывай. Отвечай кратко и по делу.""")
history = [] # История предыдущих запросов и ответов
while True:
    user_input = input("Ваш запрос: ")
    if not user_input.strip():
        continue # Пропускаем пустые строки
    user_prompt = HumanMessage(content=user_input)
    history.append(user_prompt) # Добавляем сообщение пользователя в историю
    # Формируем полный список сообщений: система + вся предыдущая история
    messages = [system_prompt] + history
    response = llm.invoke(messages)
    ai_response_message = AIMessage(content=response.content)
    history.append(ai_response_message) # Coхpаняем ответ модели в истории
    print(f"\n0твет помощника:\n{response.content}\n")