import pandas as pd
pd.read_json("client.json").to_csv("data2.csv", index=False, sep=";")